-- Creazione del Database
CREATE DATABASE ToysGroupDB;
-- Indico di voler utilizzare il db appena creato
use ToysGroupDB;

-- 1 creazione delle tabelle Product, Region e Sales

CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(50),
    Category VARCHAR(50)
    -- Constraint Product primary Key (IDRegion),
);

CREATE TABLE Region ( 
RegionID INT primary KEY, 
RegionName VARCHAR(50)
-- Constraint Region primary Key (RegionID),
);

CREATE TABLE Sales ( 
SalesID INT primary KEY, 
ProductID INT,
RegionID INT,
SalesDate DATE,
Quantity INT,
Price Decimal (10,2),
FOREIGN KEY (ProductID) REFERENCES Product (ProductID),
FOREIGN KEY (RegionID) REFERENCES Region (RegionID)
-- Constraint Sales primary Key (SalesID),
);
-- Adesso vado a popolare le tabelle 

-- Popolamento tabella Product,
INSERT INTO Product (ProductID, ProductName, Category) VALUES
(1,'Pokemon','Videogioco'),
(2,'Fifa','Videogioco'),
(3,'Mario','Videogioco'),
(4,'Lola','Bambola di pezza'),
(5,'Viola','Bambola di Pezza'),
(6,'Barbie cucina','Barbie'),
(7,'Barbie feste','Barbie'),
(8,'Dondolo bambino','Gioco in legno'),
(9,'Cubotto','Gioco in legno'),
(10,'Monopoli','Gioco da tavolo'),
(11,'Cluedo','Gioco da tavolo');

-- Popolamento tabella Region,
INSERT INTO Region (RegionID, RegionName) VALUES
(1,'Europa'),
(2,'Africa'),
(3,'America'),
(4,'Asia'),
(5,'Oceania'),
(6,'Antartide');

-- Popolamento tabella Sales,
INSERT INTO Sales (SalesID,ProductID,RegionID,SalesDate,Quantity,Price) VALUES
(1, 1, 1, '2024-01-12', 100, 50.00),
(2, 2, 2, '2024-01-22', 20, 70.00),
(3, 3, 3, '2024-01-25', 200, 60.00),
(4, 1, 2, '2024-02-01', 25, 50.00),
(5, 3, 1, '2024-02-06', 150, 60.00),
(6, 4, 4, '2024-02-11', 120, 30.00),
(7, 5, 5, '2024-02-15', 40, 35.00),
(8, 6, 6, '2024-02-17', 30, 40.00),
(9, 7, 1, '2024-03-02', 120, 50.00),
(10, 8, 2, '2024-03-05', 10, 120.00),
(11, 9, 3, '2024-03-11', 180, 36.00),
(12, 9, 4, '2024-03-18', 100, 45.00),
(13, 2, 5, '2024-03-28', 40, 70.00),
(14, 3, 6, '2024-03-30', 10, 60.00),
(15, 4, 1, '2024-04-03', 200, 30.00),
(16, 5, 2, '2024-04-05', 100, 35.00),
(17, 6, 3, '2024-04-11', 190, 40.00),
(18, 7, 4, '2024-04-15', 170, 50.00),
(19, 8, 5, '2024-04-22', 30, 120.00),
(20, 4, 1, '2024-04-04', 210, 30.00),
(21, 5, 2, '2024-04-05', 180, 35.00),
(22, 6, 3, '2024-04-10', 100, 40.00),
(23, 7, 4, '2024-04-18', 100, 50.00),
(24, 8, 5, '2024-04-20', 20, 120.00),
(25, 9, 6, '2024-04-29', 40, 45.00),
(26, 6, 6, '2023-06-07', 10, 40.00),
(27, 7, 1, '2023-07-10', 130, 50.00),
(28, 8, 2, '2023-08-19', 10, 120.00),
(29, 9, 3, '2023-08-22', 220, 45.00),
(30, 1, 4, '2023-09-21', 200, 50.00),
(31,10,1, '2023-10-23', 200, 36.00);
/*
-- Di seguito riporto le query, rispondendo in ordine 
come richiesto nell'esercizio.
*/

-- 1. Verificare che i campi definiti come PK siano univoci.

-- Verifica unicità per ProductID
SELECT ProductID, 
COUNT(*)
FROM Product
GROUP BY ProductID
HAVING COUNT(*)>1;

-- Verifica unicità per RegionID
SELECT RegionID, COUNT(*)
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1;

-- Verifica unicità per SalesID
SELECT SalesID, COUNT(*)
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) > 1;
/*
-- 2. Esporre l’elenco dei soli prodotti venduti 
e per ognuno di questi il fatturato totale per anno.
*/
Create view Fatturato_Prodotti_Annuale as (SELECT
    P.ProductName,
    YEAR(S.SalesDate) AS Year,
    SUM(S.Quantity * S.Price) AS TotalRevenue
FROM
    Sales S
    JOIN Product P ON S.ProductID = P.ProductID
GROUP BY
    P.ProductName,
    YEAR(S.SalesDate));
/*
-- 3. Esporre il fatturato totale per stato per anno. 
Ordina il risultato per data e per fatturato decrescente
*/
Create view Fatturato_per_regione AS (SELECT
    R.RegionName,
    YEAR(S.SalesDate) AS Year,
    SUM(S.Quantity * S.Price) AS TotalRevenue
FROM
    Sales S
    JOIN Region R ON S.RegionID = R.RegionID
GROUP BY
    R.RegionName,
    YEAR(S.SalesDate)
ORDER BY
    YEAR(S.SalesDate),
    TotalRevenue DESC);
    /*
    -- 4. Rispondere alla seguente domanda: 
    qual è la categoria di articoli maggiormente richiesta dal mercato?
    */
   Create view Categoria_più_richiesta As (SELECT
    P.Category,
    SUM(S.Quantity) AS Total_quantity_sales
FROM
    Sales S
    JOIN Product P ON S.ProductID = P.ProductID
GROUP BY
    P.Category
ORDER BY
    Total_quantity_sales DESC
LIMIT 1);
 /*
-- 5. Rispondere alla seguente domanda: 
quali sono, se ci sono, i prodotti invenduti? Proponi due approcci
risolutivi differenti.
*/
-- 1° approccio con utilizzo della LEFT JOIN
Create view Prodotti_invenduti_1 as (SELECT
    P.ProductName
FROM
    Product P
    LEFT JOIN Sales S ON P.ProductID = S.ProductID
WHERE
    S.SalesID IS NULL);
-- 2° approccio con una subquery
Create View Prodotti_invenduti_2 as (SELECT
    P.ProductName
FROM
    Product P
WHERE
    P.ProductID NOT IN (
        SELECT S.ProductID
        FROM Sales S
    ));
/*
-- 6. Esporre l’elenco dei prodotti 
con la rispettiva ultima data di vendita (la data di vendita più recente).
*/
Create view Data_ultima_vendita As (SELECT
    P.ProductName,
    MAX(S.SalesDate) AS LastSaleDate
FROM
    Sales S
    JOIN Product P ON S.ProductID = P.ProductID
GROUP BY
    P.ProductName);
    